import NotifyView from 'core/js/views/notifyView';

const notify = new NotifyView();
export default notify;
